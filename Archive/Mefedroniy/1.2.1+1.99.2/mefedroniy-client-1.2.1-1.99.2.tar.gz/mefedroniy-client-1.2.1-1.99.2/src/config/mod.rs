mod data;
mod file;
mod operations;

pub use data::Config;

pub const CONFIG_FILE: &str = "servers.json";