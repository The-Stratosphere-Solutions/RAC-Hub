mod keyboard;
mod mouse;
mod processor;

pub use processor::process_event;