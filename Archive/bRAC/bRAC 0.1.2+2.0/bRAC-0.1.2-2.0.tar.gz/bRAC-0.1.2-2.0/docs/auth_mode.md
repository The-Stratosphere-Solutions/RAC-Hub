# auth mode

## differences from the unauthorized mode

### message format

- there is must to be "> " after name ({name}> {text})
- if there is magic key (like 리㹰) then you must add "<" sign after it (not always)
