# FAQ

## What is RAC protocol

Sugoma’s “IRC killer”, the so-called RAC (Real Address Chat) protocol. (The worst name for a protocol.)

[*brought from here*](https://bedohswe.eu.org/text/rac/protocol.md.html)