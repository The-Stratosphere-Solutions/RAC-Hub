#!/bin/bash

rm -rf ~/.config/bRAC ~/.local/share/bRAC ~/.local/share/applications/ru.themixray.bRAC.desktop