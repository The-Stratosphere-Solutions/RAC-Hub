#!/bin/bash

cp bRAC ~/.local/bin/bRAC
chmod +x ~/.local/bin/bRAC
mkdir ~/.local/share/bRAC -p
cp misc/bRAC.png ~/.local/share/bRAC/icon.png
cp misc/bRAC.desktop ~/.local/share/applications/ru.themixray.bRAC.desktop