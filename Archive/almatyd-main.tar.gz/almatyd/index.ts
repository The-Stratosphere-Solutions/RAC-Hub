import * as net from "net";
import * as sq from "sqlite3";
import * as pp from "proxy-protocol-js";

if (process.argv[2] == null) {
	console.log("No IP specified");
	process.exit(1)
}
if (process.argv[3] == null) {
	console.log("No port specified");
	process.exit(1)
}
const ip = process.argv[2];
const port = Number(process.argv[3]);

function msgToString(time: Date, address: string, msg: string) {
	return "[" + String(time.getDate()).padStart(2, '0') + "." + String(time.getMonth() + 1).padStart(2, '0') + "." + time.getFullYear() + 
		" " + String(time.getHours()).padStart(2, '0') + ":" + String(time.getMinutes()).padStart(2, '0') + 
		"] {" + address + "} " 
		+ msg;
}


const db = new sq.Database("data.db");
db.run("CREATE TABLE IF NOT EXISTS messages (time INTEGER PRIMARY KEY, address TEXT NOT NULL, msg TEXT NOT NULL) STRICT");


let msize = 0;
db.each("SELECT time, address, msg FROM messages", (err: Error, m: {time: number; address: string; msg: string}) => {
	msize += textEncoder.encode(msgToString(new Date(m.time), m.address, m.msg)).length
});

const textEncoder = new TextEncoder();
let srv = net.createServer(function(socket: net.Socket) {
	let a = socket.address() as net.AddressInfo;
	if (!a.hasOwnProperty('address')) {
		console.log("?!?!?!");
		socket.end();
		return;
	}
	let addr = a.address;
	socket.on('data', function(data: Buffer | string) {
		if (data[0] === 'P'.charCodeAt(0)) {
			if (addr == "127.0.0.1") {
				let s = String(data);
				let p = pp.V1ProxyProtocol.parse(s);
				addr = p.source.ipAddress;
				if (typeof p.data === 'undefined') {
					return;
				} else {
					data = data.slice(s.search("\r") + 2);
				}
			} else {
				console.log("Address " + addr + " tried to use proxy protocol.");
			}
		}
		switch (data[0]) {
			case 0x30:
				const store = db.prepare("INSERT INTO messages VALUES (?,?,?)");
				let t = new Date;
				let a = addr;
				let s = data.slice(1);
				if (s.slice(-1) != "\n") {
					s += "\n";
				}
				let m = String(s).replace("/\n/g", "\\n").replace("/\x1b/g", "\\x1b");
				msize += textEncoder.encode(msgToString(t, a, m)).length
				store.run(Number(t),a,m);
				store.finalize();
				socket.end()
				return;
			case 0x31:
				socket.write(String(msize));
				socket.end();
				return;
			case 0x32:
				let str = "";
				db.each("SELECT time, address, msg FROM messages", (err: Error, m: {time: number; address: string; msg: string}) => {
					str += msgToString(new Date(m.time), m.address, m.msg);
				}, () => {
					socket.write(str);
				});
				return;
		}
		console.log(addr + "???" + data[0]);
	});
	socket.on('error', function(e: Error) {
		console.log(e.stack);
	});
})

console.log("Starting.");
srv.listen(port, ip);
