Server for the [Sugoma's RAC protocol](https://bedohswe.eu.org/text/rac/protocol.md.html).


npm i && npx tsc && node . IP PORT
