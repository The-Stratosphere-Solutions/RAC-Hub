# RAC Protocol

Default port - 42666

All the packets are serverbound and socket closes after processing them

## Sending messages

Client sends:

- Byte `0x01`
- Message text

## Reading messages

### Getting message length

Client sends:

- Byte `0x00`

Server sends:

- Size of all messages in ASCII (data_size)

### Normal reading

*Firstly, process getting message length packet*

Client sends:

- Byte `0x01`

Server sends:

- All messages

### Chunked reading

*Firstly, process getting message length packet*

Client sends:

- Byte `0x02`
- Size of messages you have in ASCII (last_size)

Server sends:

- All new messages

*for example: if you want to read last N bytes, last_size = data_size - N*

## Sending authorized messages

Client sends:

- Byte `0x02`
- Username
- `\n`
- Password
- `\n`
- Message

Server sends:

- nothing if message was sent successfully
- `0x01` if the user does not exists
- `0x02` if the password is incorrect

## Registration users

Client sends:

- Byte `0x03`
- Username
- `\n`
- Password

Server sends:

- nothing if user was registered successfully
- `0x01` if the username is already taken

# RACS Protocol

Default port - 42667

The same as RAC, but wrapped with TLS

# WRAC Protocol

Default port - 52666

Uses websocket for connections, and sends binary data only

Totally inherits all packets except reading messages packets writed here

## Reading messages

### Normal reading

~~*Firstly, process getting message length packet*~~

This packet is independent from getting message length packet.

Client sends:

- **Byte `0x00`**
- Byte `0x01`

Server sends:

- All messages

### Chunked reading

~~*Firstly, process getting message length packet*~~

This packet is independent from getting message length packet.

Client sends:

- **Byte `0x00`**
- Byte `0x02`
- Size of messages you have in ASCII (last_size)

Server sends:

- All new messages

# WRACS Protocol

Default port - 52667

Just the same WRAC protocol but wrapped with TLS, like RACS