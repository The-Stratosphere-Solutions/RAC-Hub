# cRACk
client for RAC kettles

known issues:
- no auth
- possible ansi code hack vzlom ddos attack
- if server's messages get less than before, client gonna crash or idk
