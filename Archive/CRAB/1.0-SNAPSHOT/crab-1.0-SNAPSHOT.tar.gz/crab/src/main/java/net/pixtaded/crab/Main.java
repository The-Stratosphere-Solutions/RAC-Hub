package net.pixtaded.crab;

import net.pixtaded.crab.client.CrabClient;
import net.pixtaded.crab.server.CrabServer;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        chooseMode(scanner);
        scanner.close();
    }

    private static void chooseMode(Scanner scanner) {
        System.out.println("Choose mode (1 - client, 2 - server): ");

        int choice = scanner.nextInt();

        if (choice == 1) {
            CrabClient client = new CrabClient();
            client.run();
        } else if (choice == 2) {
            CrabServer server = new CrabServer();
            server.run();
        } else {
            chooseMode(scanner);
        }
    }

}