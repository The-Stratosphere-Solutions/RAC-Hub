package net.pixtaded.crab.common;

public record Logs(int sizeInBytes, String content) {
}
