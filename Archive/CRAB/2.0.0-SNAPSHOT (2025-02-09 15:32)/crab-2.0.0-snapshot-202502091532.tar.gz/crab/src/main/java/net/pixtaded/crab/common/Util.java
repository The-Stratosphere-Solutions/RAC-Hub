package net.pixtaded.crab.common;

import java.io.BufferedReader;
import java.io.IOException;

public class Util {
    public static String readAsciiNumber(BufferedReader in) throws IOException {
        char[] buffer = new char[10];
        int response = in.read(buffer);
        return new String(buffer).trim();
    }
}
