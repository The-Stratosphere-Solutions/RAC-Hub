package net.pixtaded.crab.server;
import net.pixtaded.crab.common.Crab;
import net.pixtaded.crab.common.Logs;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class CrabServer implements Crab {

    private ServerSocket serverSocket;
    private boolean isStopped = false;
    private int port;
    private final Database db;
    public Logs cache = new Logs(0, "");

    public CrabServer() {
        this.db = new Database("data.db");
    }

    public CrabServer(int port) {
        this.db = new Database("data.db");
        this.port = port;
    }

    @Override
    public void run() {
        try {
            if (this.port == 0)
                setup();
            this.cache = getDb().getLogs();
            listen();
        } catch (IOException e) {
            if (!isStopped) System.err.println("Error starting server: " + e.getMessage());
        } finally {
            stop();
        }
    }

    private void setup() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter server port: ");
        while (true) {
            try {
                port = Integer.parseInt(scanner.nextLine());
                if (port > 0 && port <= 65535) {
                    break;
                } else {
                    System.out.println("Enter a correct port (1-65535): ");
                }
            } catch (NumberFormatException e) {
                System.out.println("Enter a correct port number: ");
            }
        }
    }

    private void listen() throws IOException {
        Scanner scanner = new Scanner(System.in);
        serverSocket = new ServerSocket(port);
        System.out.printf("Server successfully started! Listening on port %s.\nTo stop the server, type 'q'.\n", port);
        ServerCLI cli = new ServerCLI(scanner, this);
        new Thread(cli).start();
        while (!isStopped) {
            Socket socket = serverSocket.accept();
            ServerThread thread = new ServerThread(socket, this);
            new Thread(thread).start();
        }
    }

    public synchronized void stop() {
        isStopped = true;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException e) {
            System.err.println("An error occured while closing the socket: " + e.getMessage());
        } finally {
            System.exit(0);
        }
    }

    public Database getDb() {
        return db;
    }
}
