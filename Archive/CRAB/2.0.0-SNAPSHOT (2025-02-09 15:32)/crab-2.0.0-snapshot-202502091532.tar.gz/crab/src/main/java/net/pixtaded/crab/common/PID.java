package net.pixtaded.crab.common;

public class PID {
    public static final byte LOGS_SIZE = 0x00;
    public static final byte COMMUNICATION = 0x01;
    public static final byte LOGS = 0x02;
}
