package net.pixtaded.crab.server;

import net.pixtaded.crab.common.Logs;
import net.pixtaded.crab.common.Sanitizer;
import net.pixtaded.crab.common.Util;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static net.pixtaded.crab.common.PID.*;

public class ServerThread implements Runnable {

    private final Socket socket;
    private PrintWriter out;
    private final BufferedReader in;
    private OutputStream output;
    private final InputStream input;
    private final CrabServer server;

    public ServerThread(Socket socket, CrabServer server) throws IOException {
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.output = socket.getOutputStream();
        this.input = socket.getInputStream();
        this.server = server;
    }

    @Override
    public void run() {
        try {
            byte[] PID = readPID();
            if (PID.length == 0) {
                socket.close();
                return;
            }
            switch (PID[0]) {
                case COMMUNICATION -> {
                    String msg = new String(input.readNBytes(4096), StandardCharsets.UTF_8).trim();
                    Date date = new Date();
                    String address = socket.getInetAddress().getHostAddress();

                    String s = Sanitizer.sanitizeString(msg, true);
                    String newContent = server.cache.content() + Sanitizer.formatMessage(date.getTime(), address, s);
                    server.cache = new Logs(newContent.getBytes().length, newContent);

                    new Thread(new LogDBThread(date, address, msg)).start();
                } case LOGS_SIZE -> {
                    respond(String.valueOf(server.cache.sizeInBytes()));
                    byte[] logPID = readPID();
                    if (logPID.length == 0) {
                        socket.close();
                        return;
                    }
                    sendLogs(logPID[0]);
                } default -> System.out.println("PID not implemented: " + PID[0]);
            }
            socket.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private byte[] readPID() throws IOException {
        return input.readNBytes(1);
    }

    private void sendLogs(byte PID) throws IOException {
        if (PID == COMMUNICATION) respond(server.cache.content());
        if (PID == LOGS) {
            String clientSize = Util.readAsciiNumber(in);
            int clientSizeNum = Integer.parseInt(clientSize);
            byte[] serverLogs = server.cache.content().getBytes(StandardCharsets.UTF_8);
            int logPartSize = serverLogs.length - clientSizeNum;
            byte[] logPart = new byte[logPartSize];
            System.arraycopy(serverLogs, serverLogs.length - logPartSize, logPart, 0, logPartSize);
            respond(logPart);
        }
    }

    private void respond(byte[] data) throws IOException {
        socket.getOutputStream().write(data);
        socket.getOutputStream().flush();
    }

    private void respond(String utf8) throws IOException {
        respond(utf8.getBytes(StandardCharsets.UTF_8));
    }

    private class LogDBThread implements Runnable {

        Date date;
        String msg;
        String address;

        public LogDBThread(Date date, String address, String msg) {
            this.date = date;
            this.msg = msg;
            this.address = address;
        }

        @Override
        public void run() {
            server.getDb().logMessage(date, address, msg);
        }
    }
}
