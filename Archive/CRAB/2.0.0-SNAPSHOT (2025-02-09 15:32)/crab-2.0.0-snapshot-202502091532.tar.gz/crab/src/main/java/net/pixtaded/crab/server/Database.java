package net.pixtaded.crab.server;

import net.pixtaded.crab.common.Logs;
import net.pixtaded.crab.common.Sanitizer;

import java.sql.*;
import java.util.Date;

public class Database {

    private Connection connection;

    public Database(String dbName) {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:./" + dbName);
            createTable();
        } catch (SQLException e) {
            System.err.println("Failed to connect to database: " + e.getMessage());
        }
    }

    private void createTable() throws SQLException {
        execute("CREATE TABLE IF NOT EXISTS messages (time INTEGER PRIMARY KEY, address TEXT NOT NULL, msg TEXT NOT NULL) STRICT"); // almatyd format
    }

    public ResultSet query(String q) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(q);
        if (!rs.isAfterLast()) {
            return rs;
        } else return null;
    }

    public void execute(String q) throws SQLException {
        Statement statement = connection.createStatement();
        statement.execute(q);
        statement.close();
    }

    public void logMessage(Date date, String address, String message) {
        String sql = "INSERT INTO messages (time, address, msg) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setLong(1, date.getTime());
            pstmt.setString(2, address);
            pstmt.setString(3, Sanitizer.sanitizeString(message, true));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Logs getLogs() {
        StringBuilder s = new StringBuilder();
        try (ResultSet rs = query("SELECT time, address, msg FROM messages")) {
            while (rs.next()) {
                s.append(Sanitizer.formatMessage(rs.getLong(1), rs.getString(2), rs.getString(3)));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        String logsString = s.toString();
        return new Logs(logsString.isEmpty() ? 0 : logsString.getBytes().length, logsString);
    }
}
