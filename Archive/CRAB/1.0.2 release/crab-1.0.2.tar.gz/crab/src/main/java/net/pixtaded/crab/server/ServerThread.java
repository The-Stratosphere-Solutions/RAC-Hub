package net.pixtaded.crab.server;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static net.pixtaded.crab.common.PID.*;

public class ServerThread implements Runnable {

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private OutputStream output;
    private InputStream input;
    private byte PID;
    private CrabServer server;

    public ServerThread(Socket socket, CrabServer server) throws IOException {
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.output = socket.getOutputStream();
        this.input = socket.getInputStream();
        this.server = server;
    }

    @Override
    public void run() {
        try {
            byte[] PID = input.readNBytes(1);
            switch (PID[0]) {
                case MESSAGE -> {
                    server.getDb().logMessage(new Date(), socket.getInetAddress().getHostAddress(), new String(input.readNBytes(4096), StandardCharsets.UTF_8).trim());
                    socket.close();
                } case LOGS -> {
                    respond(server.getDb().getLogs());
                } case LOGS_SIZE -> {
                    respond(String.valueOf(server.getDb().getLogSize()));
                } default -> {
                    System.out.println("PID not implemented: " + PID[0]);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void respond(byte[] data) throws IOException {
        socket.getOutputStream().write(data);
        socket.getOutputStream().flush();
        socket.close();
    }

    private void respond(String utf8) throws IOException {
        respond(utf8.getBytes(StandardCharsets.UTF_8));
    }
}
