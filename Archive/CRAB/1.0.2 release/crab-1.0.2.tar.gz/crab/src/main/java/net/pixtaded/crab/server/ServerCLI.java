package net.pixtaded.crab.server;

import java.util.Scanner;

public class ServerCLI implements Runnable {

    Scanner scanner;
    CrabServer server;

    public ServerCLI(Scanner scanner, CrabServer server) {
        this.scanner = scanner;
        this.server = server;
    }

    @Override
    public void run() {
        while (true) {
            if (scanner.nextLine().equalsIgnoreCase("q")) {
                System.out.println("The server is stopping...");
                server.stop();
                break;
            }
        }
    }
}
