package net.pixtaded.crab.common;

public interface Crab {
    void run();
}
