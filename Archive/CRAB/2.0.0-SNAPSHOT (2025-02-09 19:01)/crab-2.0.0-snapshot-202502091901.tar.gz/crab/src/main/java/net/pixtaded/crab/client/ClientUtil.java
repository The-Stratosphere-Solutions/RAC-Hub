package net.pixtaded.crab.client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientUtil {

    public static final String COLOR_KEY = "\u2550\u2550\u2550";

    public static final ClientColor[] colors = {
            new ClientColor( COLOR_KEY + "(<.*?>)", "\033[0;31m$1\033[0m"),
            new ClientColor("\uB9AC\u3E70(<.*?>)", "\033[0;32m$1\033[0m"),
            new ClientColor(" (<.*?>)", " \033[0;34m$1\033[0m")
            /*
            I'm too lazy to add a message parser, which is absolutely required for Mefedroniy color support. For now, it will be just white.
            Also, there is another problem with that - there is no "server log format" in the protocol specification,
            and I want my client to be as compatible as possible.
            */
    };

    public static String clientColors(String s) {
        for (ClientColor color : colors) s = matchClientKey(s, color);
        return s;
    }

    private static String matchClientKey(String s, ClientColor color) {
        Pattern p = Pattern.compile(color.regex());
        Matcher m = p.matcher(s);

        return m.replaceAll(color.color());
    }
}
