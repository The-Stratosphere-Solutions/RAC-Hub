package net.pixtaded.crab.client;

public record ClientColor(String regex, String color) {
}
