package net.pixtaded.crab.common;

public class Sanitizer {
    public static String sanitizeString(String s, boolean sanitizeNewlines) {
        String sanitized = s.replaceAll("[\010\015\033]", "");
        if (sanitizeNewlines) {
            sanitized = sanitized.replaceAll("\n", "\\\\n");
            if (!s.endsWith("\n")) sanitized += '\n';
        } else {
            sanitized = sanitized.replaceAll("\n\n+", "\n");
        }
        return sanitized;
    }

    public static String formatMessage(long timeMillis, String address, String content) {
        return String.format("[%td.%1$tm.%1$tY %1$tR] {%s} %s", timeMillis, address, content);
    }
}