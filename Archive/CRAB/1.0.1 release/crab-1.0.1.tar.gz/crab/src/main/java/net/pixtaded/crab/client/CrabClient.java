package net.pixtaded.crab.client;

import net.pixtaded.crab.common.Crab;
import net.pixtaded.crab.common.Sanitizer;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import static net.pixtaded.crab.common.PID.*;

public class CrabClient implements Crab {
    private String serverAddress;
    private int port;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private int lastBufferLength = 0;
    private String nickname;

    public CrabClient() {
        this.nickname = "";
    }

    public CrabClient(String serverAddress, int port, String nickname) {
        this.serverAddress = serverAddress;
        this.port = port;
        if (nickname != null)
            this.nickname = "<" + nickname + "> ";
        else
            this.nickname = "";
    }

    @Override
    public void run() {
        try {
            if (this.serverAddress == null)
                setup();
            connect();
            communicate();
        } catch (IOException e) {
            System.err.println("Error connecting to the server: " + e.getMessage());
        } finally {
            closeConnection();
        }
    }

    private void setup() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter server address: ");
        serverAddress = scanner.nextLine();

        System.out.print("Enter the port: ");
        while (true) {
            try {
                port = Integer.parseInt(scanner.nextLine());
                if (port > 0 && port <= 65535) {
                    break;
                } else {
                    System.out.println("Enter the correct port (1-65535): ");
                }
            } catch (NumberFormatException e) {
                System.out.println("Enter a correct port number: ");
            }
        }

        System.out.print("Enter your nickname (leave empty for no nickname): ");
        nickname = scanner.nextLine();
        if (nickname != "")
            nickname = "<" + nickname + "> ";
    }

    private void connect() throws IOException {
        socket = new Socket();
        socket.connect(new InetSocketAddress(serverAddress, port), 2000);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    private void communicate() throws IOException {
        Scanner scanner = new Scanner(System.in);
        String message;

        while (true) {
            System.out.print("\033[H\033[2J");
            getLogs();
            System.out.print("Enter a message (or type '/exit' to exit): ");
            message = scanner.nextLine();

            if (message.equalsIgnoreCase("/exit")) {
                break;
            }

            if (!message.isEmpty()) sendPacket(MESSAGE, this.nickname + message);
        }
    }

    private void sendPacket(byte PID, String argument) throws IOException {
        String formattedMessage = String.valueOf((char) PID) + argument + "\n";

        out.print(formattedMessage);
        out.flush();

        receiveResponse(PID);
    }

    private void receiveResponse(byte PID) throws IOException {
        switch (PID) {
            case LOGS_SIZE -> {
                char[] buffer = new char[10];
                int response = in.read(buffer);
                lastBufferLength = Integer.parseInt(new String(buffer).trim());
            } case LOGS -> {
                byte[] bytes = socket.getInputStream().readNBytes(lastBufferLength);
                System.out.print(Sanitizer.sanitizeString(new String(bytes, StandardCharsets.UTF_8), false));
            } default -> {
            }
        }
        closeConnection();
        connect();
    }

    private void closeConnection() {
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            System.err.println("An error occured while closing the connection: " + e.getMessage());
        }
    }

    private void getLogs() throws IOException {
        sendPacket(LOGS_SIZE, "");
        sendPacket(LOGS, "");
    }
}
