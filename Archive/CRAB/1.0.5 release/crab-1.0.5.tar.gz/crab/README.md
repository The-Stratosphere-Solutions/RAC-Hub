# CRAB (Crimean RAC Bundle)

CRAB is a Java client and server implementation of the RAC (Real Address Chat) protocol, designed to facilitate communication in a lightweight and efficient manner.

## Table of Contents

- [Overview](#overview)
- [Installation](#installation)
- [Usage](#usage)
- [RAC Protocol](#rac-protocol)

## Overview

CRAB aims to provide a simple and effective implementation of the RAC protocol, which is humorously referred to as Mr. Sugoma’s “IRC killer.” The protocol allows clients to send messages to a server, which processes them according to predefined message types.

## Installation

To get started with CRAB, follow these steps:

1. **Clone the repository:**
   ```bash
   git clone https://gitea.bedohswe.eu.org/pixtaded/crab.git
   cd crab
   ```

2. **Build the project:**
   Ensure you have Java Development Kit (JDK) of version 17 or higher installed. You can build the project using Maven:
   ```bash
   ./gradlew clean build
   ```

3. **Run the bundle**: You will have the built .tar and .zip packages in ./build/distributions directory.

## Usage

Once the server is running, clients can connect to it and send messages according to the RAC protocol. The client will need to specify the server's address and port to establish a connection.

## RAC Protocol

You can see the RAC protocol documentation [here](https://bedohswe.eu.org/text/rac/protocol.md.html).