package net.pixtaded.crab.server;

import net.pixtaded.crab.common.Logs;
import net.pixtaded.crab.common.Sanitizer;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static net.pixtaded.crab.common.PID.*;

public class ServerThread implements Runnable {

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private OutputStream output;
    private InputStream input;
    private byte PID;
    private CrabServer server;

    public ServerThread(Socket socket, CrabServer server) throws IOException {
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.output = socket.getOutputStream();
        this.input = socket.getInputStream();
        this.server = server;
    }

    @Override
    public void run() {
        try {
            byte[] PID = input.readNBytes(1);
            if (PID.length == 0) {
                socket.close();
                return;
            }
            switch (PID[0]) {
                case MESSAGE -> {
                    Date date = new Date();
                    String msg = new String(input.readNBytes(4096), StandardCharsets.UTF_8).trim();
                    String address = socket.getInetAddress().getHostAddress();

                    String s = Sanitizer.sanitizeString(msg, true);
                    String newContent = server.cache.content() + Sanitizer.formatMessage(date.getTime(), address, s);
                    server.cache = new Logs(newContent.getBytes().length, newContent);

                    new Thread(new LogDBThread(date, address, msg)).start();
                } case LOGS -> {
                    respond(server.cache.content());
                } case LOGS_SIZE -> {
                    respond(String.valueOf(server.cache.sizeInBytes()));
                } default -> {
                    System.out.println("PID not implemented: " + PID[0]);
                }
            }
            socket.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void respond(byte[] data) throws IOException {
        socket.getOutputStream().write(data);
        socket.getOutputStream().flush();
    }

    private void respond(String utf8) throws IOException {
        respond(utf8.getBytes(StandardCharsets.UTF_8));
    }

    private class LogDBThread implements Runnable {

        Date date;
        String msg;
        String address;

        public LogDBThread(Date date, String address, String msg) {
            this.date = date;
            this.msg = msg;
            this.address = address;
        }

        @Override
        public void run() {
            server.getDb().logMessage(date, address, msg);
        }
    }
}
