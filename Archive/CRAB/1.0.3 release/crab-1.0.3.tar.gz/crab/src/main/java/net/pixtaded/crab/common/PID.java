package net.pixtaded.crab.common;

public class PID {
    public static final byte MESSAGE = 0x30;
    public static final byte LOGS_SIZE = 0x31;
    public static final byte LOGS = 0x32;
}
