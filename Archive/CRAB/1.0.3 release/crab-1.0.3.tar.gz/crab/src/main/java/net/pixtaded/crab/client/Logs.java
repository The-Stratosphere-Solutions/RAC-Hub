package net.pixtaded.crab.client;

public record Logs(int sizeInBytes, String content) {
}
