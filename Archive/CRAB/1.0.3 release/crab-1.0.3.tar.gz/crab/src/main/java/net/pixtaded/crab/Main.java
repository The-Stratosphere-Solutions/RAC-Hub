package net.pixtaded.crab;

import net.pixtaded.crab.client.CrabClient;
import net.pixtaded.crab.server.CrabServer;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        if (args.length == 0) {
            Scanner scanner = new Scanner(System.in);
            chooseMode(scanner);
            scanner.close();
            return;
        }
        switch (args[0]) {
            case "help" -> {
                System.out.println("crab help - print this message.");
                System.out.println("crab client <ip> <port> [nick] - connect to a server.");
                System.out.println("crab server <port> - start a server.");
            }
            case "client" -> {
                CrabClient client;
                try {
                    client = new CrabClient(args[1], Integer.parseInt(args[2]), args.length == 4 ? args[3] : null);
                } catch (NumberFormatException e) {
                    System.err.println("Port is not a number.");
                    return;
                }
                client.run();
            }
            case "server" -> {
                CrabServer server;
                try {
                    server = new CrabServer(Integer.parseInt(args[1]));
                } catch (NumberFormatException e) {
                    System.err.println("Port is not a number.");
                    return;
                }
                server.run();
            }
            default -> {
                System.err.println("Unknown argument");
                return;
            }
        }
    }

    private static void chooseMode(Scanner scanner) {
        System.out.println("Choose mode (1 - client, 2 - server): ");

        int choice = scanner.nextInt();

        if (choice == 1) {
            CrabClient client = new CrabClient();
            client.run();
        } else if (choice == 2) {
            CrabServer server = new CrabServer();
            server.run();
        } else {
            chooseMode(scanner);
        }
    }

}
