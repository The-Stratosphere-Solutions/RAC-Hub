package net.pixtaded.crab.common;

public class Sanitizer {
    public static String sanitizeString(String s, boolean sanitizeNewlines) {
        String sanitized = s.replaceAll("\033", "");
        if (sanitizeNewlines) {
            sanitized = sanitized.replaceAll("\n", "\\\\n");
            if (!s.endsWith("\n")) sanitized += '\n';
        }
        return sanitized;
    }
}
