Client for the [Sugoma's RAC protocol](https://bedohswe.eu.org/text/rac/protocol.md.html).


Usage: ./dobroho_vechora.bash \<MODE\> \<IP\> \<PORT\> [NICK]


Modes:

* send: Reads the message from stdin and send it to the server.

* receive: Writes the message buffer from the server to stdout.

* interactive: Waits on stdin for lines with commands.


Available commands:

* I: Calls the editor (from VISUAL variable, if unset EDITOR is used. If both unset vi is used) and send the message if it is not empty.

* i: Send the next string from stdout.

* L: Ask the server for current chat buffer's length.

* l: Print current chat buffer's length.

* w: Poll the server for new messages, print the chat buffer when they appear and execute the command specified by "DOBROHO_VECHORA_ON_WAIT" environment variable.

* p: Print the chat buffer.

* q: Exit.

* e: Toggle encryption.

* E: Set encryption password. (Can also be set via "DOBROHO_VECHORA_ENCRYPTION_PASSWORD" environment variable.)

* n: Change nickname.


Client prints "?" on unknown commands.
